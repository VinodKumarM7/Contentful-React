import Login from '../components/templates/Login';

export default function Home() {
  return <Login />;
}
