import LoginForm from '../organisms/LoginForm';
import { useState } from 'react';
import { useTranslation } from 'next-i18next';

export default function Login() {
  const { t } = useTranslation('common');
  const [values, setValues] = useState({ username: '', password: '' });

  const handleChange = (field) => (e) => {
    setValues({ ...values, [field]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle login logic here
    alert(t('login_success'));
  };

  return (
    <div>
      <h1>{t('login_title')}</h1>
      <LoginForm onSubmit={handleSubmit} onChange={handleChange} values={values} />
    </div>
  );
}
