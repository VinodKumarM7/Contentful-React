import Input from '../atoms/Input';

export default function FormField({ type, placeholder, value, onChange }) {
  return (
    <div>
      <Input type={type} placeholder={placeholder} value={value} onChange={onChange} />
    </div>
  );
}
