import FormField from '../molecules/FormField';
import Button from '../atoms/Button';

export default function LoginForm({ onSubmit, onChange, values }) {
  return (
    <form onSubmit={onSubmit}>
      <FormField type="text" placeholder="Username" value={values.username} onChange={onChange('username')} />
      <FormField type="password" placeholder="Password" value={values.password} onChange={onChange('password')} />
      <Button type="submit">Login</Button>
    </form>
  );
}
