
import { render, screen } from '@testing-library/react';
import Home from '../app/pages/index';

describe('Home', () => {
  it('renders the home page', () => {
    render(<Home />);
    expect(screen.getByText('Welcome')).toBeInTheDocument();
  });
});
