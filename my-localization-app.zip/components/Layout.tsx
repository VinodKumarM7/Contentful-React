import LanguageDropdown from './LanguageDropdown';

const Layout = ({ children }) => {
  return (
    <div>
      <header>
        <LanguageDropdown />
      </header>
      <main>{children}</main>
      <footer>
        <p>&copy; 2024 My Localization App</p>
      </footer>
    </div>
  );
};

export default Layout;
