import { NextIntlProvider } from 'next-intl';
import { useRouter } from 'next/router';

export default function Providers({ children }) {
  const { locale } = useRouter();
  return <NextIntlProvider locale={locale}>{children}</NextIntlProvider>;
}
