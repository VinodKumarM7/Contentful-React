import Layout from '../components/Layout';
import Providers from '../app/providers';
import '../styles/globals.css';

function MyApp({ Component, pageProps }) {
  return (
    <Providers>
      <Layout>
        <Component {...pageProps} />
      </Layout>
    </Providers>
  );
}

export default MyApp;
