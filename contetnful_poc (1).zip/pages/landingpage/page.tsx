import { fetchContentfulData } from '@/app/utills/contentfulAPI';
import { LandingPageData } from '@/app/utills/model';
import { LANDING_PAGE_QUERY } from '@/app/utills/queries';
import Image from 'next/image'

const HomePage = async () => {
  let data: LandingPageData | null = null;

  try {
    data = await fetchContentfulData<LandingPageData>(LANDING_PAGE_QUERY);
  } catch (error) {
    console.error('Error fetching Contentful data:', error);
    return <p>Failed to load content.</p>;
  }

  const topHeader = data?.landingPage2?.topHeader;
  const howitWorks = data?.landingPage2?.cardWithSmallImage;
  console.log('data--', data?.landingPage2);

  return (
    <>
    <div className="flex justify-center  bg-red-600">
      {topHeader ? (
      <header className="py-10 px-5 text-white lg:w-7/12  sm:w-full">
        <h1 className="text-3xl font-semibold ">{topHeader.morningGreeting}</h1>
        <h2 className="text-2xl font-semibold">Alex!</h2>
        <p className="text-lg">{topHeader.voucherDescription}</p>     

      </header>
      
      ) : (
        <p>No data found.</p>
      )}
    </div> 
    <div className="flex -mt-8 lg:mx-auto ml-5 mr-5 rounded-xl bg-[#f5f5f5] lg:w-7/12  sm:w-11/12  divide-x divide-dashed">
      {/* token count section */}
      <div className="w-1/2 p-2">
      {topHeader.tokenCountCollection.items.map((item, index) => (
        <div className="flex flex-col items-center justify-between" key={index}>
          {item.contentIcon && (
          <div className="flex items-center justify-center ">              
            <img
              src={item.contentIcon.url}
              alt={item.contentIcon.title}
              width={item.contentIcon.width}
              height={item.contentIcon.height}
              className="h-auto max-w-xl"
            />
            <span className="text-xl font-semibold ml-1">100</span>             
          </div> )}
          <h3 className="text-gray-950 text-sm">{item.contentDescription}</h3>              
        </div>
      ))}
      </div>
      {/* membership days section */}
      <div className="w-1/2 p-2">
        <div className="flex flex-col items-center justify-between">
          <div className="flex items-center justify-center">        
          <img src={topHeader.membershipCount.contentIcon.url}
            alt={topHeader.membershipCount.contentIcon.title}
            width={topHeader.membershipCount.contentIcon.width}
            height={topHeader.membershipCount.contentIcon.height} className="h-auto max-w-xl" />
            <span className="text-xl font-semibold ml-1">30</span>
          </div>
          <h3 className="text-gray-950 text-sm">{topHeader.membershipCount.contentDescription}</h3>
        </div>
      </div>
    </div>
      {/* how it works section */}
      { howitWorks ? (
        <div className="flex lg:mx-auto  ml-5 mr-5  lg:w-7/12  sm:w-11/12 mt-8 bg-[#ededed] rounded-lg shadow-lg">
          <div className="p-3 w-4/5">
            <h2 className="text-black text-lg font-semibold mb-2">Learn how it work!</h2>
            <p className="text-gray-700 mb-4">{howitWorks.description}</p>
          </div>
          <div className="p-2 w-1/5">
            <img src={howitWorks.icon.url}
               alt={howitWorks.icon.title}
               width={howitWorks.icon.width}
               height={howitWorks.icon.height} className="h-auto max-w-full mt-4" />
          </div>
        </div>
      ) : (
        <p>No data found</p>
      )}
    </>
  );
};

export default HomePage;
