import HomePage from "../../pages/landingpage/page";

export default function Home() {
  return (
    <div>
      <h1>Contentful POC</h1>
      <HomePage></HomePage>
    </div>
  );
}
