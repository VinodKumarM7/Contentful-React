export const LANDING_PAGE_QUERY = `
  {
    landingPage2(id: "4wvgFuqQGWXcKbKpmblc6s") {
      topHeader {
        morningGreeting
        voucherDescription
        membershipCount {
          contentIcon {
            title
            description
            url
            width
            height
          }
          contentDescription
        }
        tokenCountCollection {
          items {
            contentIcon {
              title
              description
              url
              width
              height
            }
            contentDescription
          }
        }
      }
    },
    cardWithSmallImage (id: "1sxeLqK6g7jueouAyKWOLB") {
        description,
        icon {
        title
        description
        size
        url
        width
        height
        }
    },
    featuredArticles (id: ""){
        title
    }
  }
`;
