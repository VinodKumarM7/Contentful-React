export interface LandingPageData {
    landingPage2: {
      topHeader: {
        morningGreeting: string;
        voucherDescription: string;
        membershipCount: {
          contentIcon: {
            title: string;
            description: string;
            url: string;
            width: number;
            height: number;
          };
          contentDescription: string;
        };
        tokenCountCollection: {
          items: Array<{
            contentIcon: {
              title: string;
              description: string;
              url: string;
              width: number;
              height: number;
            };
            contentDescription: string;
          }>;
        };
      };
      cardWithSmallImage: {
        description :string;
        icon :{
        title: string;
        description : string;
        url : string;
        width : string;
        height : string;
        };
      };
    };
  }
  