import { GraphQLClient } from 'graphql-request';

const CONTENTFUL_API_URL = `${process.env.CONTENTFUL_GRAPHQL_URL}/${process.env.CONTENTFUL_SPACE_ID}/`;
const ACCESS_TOKEN = process.env.CONTENTFUL_ACCESS_TOKEN;

const client = new GraphQLClient(CONTENTFUL_API_URL, {
  headers: {
    Authorization: `Bearer ${ACCESS_TOKEN}`,
  },
});

export const fetchContentfulData = async <T>(query: string): Promise<T> => {
  return client.request<T>(query);
};