import { useRouter } from 'next/router';

export default function LanguageDropdown() {
  const router = useRouter();
  const { country, lang } = router.query;

  const handleLanguageChange = (e) => {
    const newLang = e.target.value;
    router.push(`/${country}/${newLang}${router.pathname}`);
  };

  return (
    <select value={lang} onChange={handleLanguageChange}>
      <option value="en">English</option>
      <option value="de">Deutsch</option>
      <option value="fr">Français</option>
      <option value="es">Español</option>
    </select>
  );
}
