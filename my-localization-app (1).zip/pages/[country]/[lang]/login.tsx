import { useTranslations } from 'next-intl';
import { useRouter } from 'next/router';

export default function Login() {
  const t = useTranslations('login');
  const router = useRouter();
  const { country, lang } = router.query;

  const handleSubmit = () => {
    router.push(`/${country}/${lang}/dashboard`);
  };

  return (
    <div>
      <h1>{t('title')}</h1>
      <button onClick={handleSubmit}>{t('button')}</button>
    </div>
  );
}

export async function getStaticProps({ params }) {
  return {
    props: {
      messages: (await import(`../../../locales/${params.lang}.json`)).default
    }
  };
}

export async function getStaticPaths() {
  return {
    paths: [
      { params: { country: 'us', lang: 'en' } },
      { params: { country: 'de', lang: 'de' } },
      { params: { country: 'fr', lang: 'fr' } },
      { params: { country: 'es', lang: 'es' } }
    ],
    fallback: false
  };
}
