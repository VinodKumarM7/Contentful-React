import { useTranslations } from 'next-intl';

export default function Dashboard() {
  const t = useTranslations('dashboard');
  return (
    <div>
      <h1>{t('welcome')}</h1>
    </div>
  );
}

export async function getStaticProps({ params }) {
  return {
    props: {
      messages: (await import(`../../../locales/${params.lang}.json`)).default
    }
  };
}

export async function getStaticPaths() {
  return {
    paths: [
      { params: { country: 'us', lang: 'en' } },
      { params: { country: 'de', lang: 'de' } },
      { params: { country: 'fr', lang: 'fr' } },
      { params: { country: 'es', lang: 'es' } }
    ],
    fallback: false
  };
}
